-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Хост: localhost
-- Время создания: Окт 20 2020 г., 22:48
-- Версия сервера: 5.7.21-20-beget-5.7.21-20-1-log
-- Версия PHP: 5.6.40

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `keh192_mvc`
--

-- --------------------------------------------------------

--
-- Структура таблицы `tasks`
--
-- Создание: Окт 20 2020 г., 18:56
-- Последнее обновление: Окт 20 2020 г., 19:37
--

DROP TABLE IF EXISTS `tasks`;
CREATE TABLE `tasks` (
  `id` int(5) NOT NULL,
  `user_name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `text` text NOT NULL,
  `status` int(11) NOT NULL,
  `is_modified_by_admin` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `tasks`
--

INSERT INTO `tasks` (`id`, `user_name`, `email`, `text`, `status`, `is_modified_by_admin`) VALUES
(1, 'test', 'test', 'test', 1, 0),
(2, 'test', 'test', 'test', 1, 0),
(3, 'test', 'test', 'test', 1, 0),
(4, 'conttjztp', 'conttjztp', 'conttjztp', 1, 0),
(5, 'EdgarTem', 'EdgarTem', 'EdgarTem', 1, 0),
(6, 'Thomasblasy', 'Thomasblasy', 'Thomasblasy', 1, 0),
(7, 'Михаил', 'Михаил', 'Михаил', 1, 0),
(8, 'Пашка', 'Пашка', 'Пашка', 1, 0),
(9, 'test', 'test', 'test', 1, 0),
(10, 'test2', 'test2', 'test2', 1, 0),
(11, 'fdh', 'fdh', 'fdh', 1, 0),
(12, 'fdh', 'fdh', 'fdh', 5, 0),
(13, 'test', '123@mail.ru', 'Test XSS hack! &amp;lt;script&amp;gt;alert(123)&amp;lt;/script&amp;gt;', 5, 1),
(14, 'Пашка', '123@mail.ru', 'More XSS Attack! alert(123)', 5, 1),
(15, 'Test descr', 'test_descr@mail.ru', 'Testing descr edition', 1, 0);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--
-- Создание: Окт 17 2020 г., 08:17
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` int(5) NOT NULL,
  `login` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `password`) VALUES
(1, 'admin', '202cb962ac59075b964b07152d234b70');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
